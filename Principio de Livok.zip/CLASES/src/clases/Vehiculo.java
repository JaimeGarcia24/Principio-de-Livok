
package clases;

abstract class Vehiculo {
    
    protected double kilometrosRecorridos;
    
    
    public abstract void mover (double distancia);
    
    
    public abstract double calcularAutonomia();
    
}
